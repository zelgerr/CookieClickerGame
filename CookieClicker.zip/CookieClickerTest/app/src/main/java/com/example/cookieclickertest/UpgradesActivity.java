package com.example.cookieclickertest;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.cookieclickertest.R;

public class UpgradesActivity extends AppCompatActivity {

    private Button upgradeButton1;
    private int upgradeCost = 50;

    private int cookiesPerClick = 1; // Grundwert
    private int cookiesPerSecond = 0;
    private int cookieCount = 0;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upgrades);

        upgradeButton1 = findViewById(R.id.upgradeButton1);

        upgradeButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentCookies = getIntent().getIntExtra("cookieCount", 0);

                if (currentCookies >= upgradeCost) {
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("upgradeLevel", 1);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                } else {
                    Toast.makeText(UpgradesActivity.this, "Nicht genügend Cookies!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
