package com.example.cookieclickertest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.cookieclickertest.R;

public class MainActivity extends AppCompatActivity {

    // Variablen für den Cookie-Zähler und Cookies pro Klick
    private int cookieCount = 0;
    private int cookiesPerClick = 1;

    // UI-Elemente
    private TextView cookieCountTextView;
    private ImageButton cookieButton;
    private Button upgradeButton;

    // MediaPlayer für Soundeffekte
    private MediaPlayer clickSound;
    private MediaPlayer upgradeSound;

    // Konstanten für den Upgrade-Request-Code und SharedPreferences-Schlüssel
    private static final int UPGRADE_REQUEST_CODE = 1;
    private static final String PREFS_NAME = "CookieClickerPrefs";
    private static final String COOKIE_COUNT_KEY = "cookieCount";
    private static final String COOKIES_PER_CLICK_KEY = "cookiesPerClick";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // UI-Elemente initialisieren
        cookieCountTextView = findViewById(R.id.cookie_count);
        cookieButton = findViewById(R.id.cookie_button);
        upgradeButton = findViewById(R.id.upgradeButton);

        // MediaPlayer für Klick- und Upgrade-Sounds initialisieren
        clickSound = MediaPlayer.create(this, R.raw.click_sound);
        upgradeSound = MediaPlayer.create(this, R.raw.upgrade_sound);

        // Daten laden
        loadData();

        // Klick-Listener für den Cookie-Button
        cookieButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Cookies pro Klick hinzufügen
                cookieCount += cookiesPerClick;
                cookieCountTextView.setText("Cookies: " + cookieCount);

                // Klick-Sound abspielen
                clickSound.start();

                // Daten speichern
                saveData();
            }
        });

        // Klick-Listener für den Upgrade-Button
        upgradeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Upgrade-Aktivität starten und aktuelle Cookie-Anzahl übergeben
                Intent intent = new Intent(MainActivity.this, com.example.cookieclickertest.UpgradesActivity.class);
                intent.putExtra("cookieCount", cookieCount);
                startActivityForResult(intent, UPGRADE_REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Überprüfung, ob die Upgrade-Aktivität erfolgreich beendet wurde
        if (requestCode == UPGRADE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            // Upgrade-Level aus der zurückgegebenen Intent-Daten erhalten
            int upgradeLevel = data.getIntExtra("upgradeLevel", 0);
            if (upgradeLevel == 1) {
                // Cookies pro Klick erhöhen und Cookie-Anzahl reduzieren
                cookiesPerClick++;
                cookieCount -= 50;
                cookieCountTextView.setText("Cookies: " + cookieCount);

                // Upgrade-Sound abspielen
                upgradeSound.start();

                // Daten speichern
                saveData();
            }
        }
    }

    // Methode zum Speichern der Daten in SharedPreferences
    private void saveData() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(COOKIE_COUNT_KEY, cookieCount);
        editor.putInt(COOKIES_PER_CLICK_KEY, cookiesPerClick);
        editor.apply();
    }

    // Methode zum Laden der Daten aus SharedPreferences
    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        cookieCount = sharedPreferences.getInt(COOKIE_COUNT_KEY, 0);
        cookiesPerClick = sharedPreferences.getInt(COOKIES_PER_CLICK_KEY, 1);
        cookieCountTextView.setText("Cookies: " + cookieCount);
    }
}
